export class Personne{

	constructor(

		public id:number,
		public nom:string,
		public prenom:string,

		){
	}

}