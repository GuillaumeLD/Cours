package com.tactfactory.testing.adapter;

public class User {

}
