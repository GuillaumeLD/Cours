package com.tactfactory.testing.adapter;

import java.util.ArrayList;
import java.util.List;

public class Adaptee1 {

	public List<User> getUsers() {
		List<User> users = new ArrayList<User>();
		return users;
	}

}
