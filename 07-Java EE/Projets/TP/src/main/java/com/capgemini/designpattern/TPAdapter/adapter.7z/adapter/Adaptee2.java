package com.tactfactory.testing.adapter;

import java.util.ArrayList;
import java.util.List;

public class Adaptee2 {

	public List<User> getUsers() {
		List<User> users = new ArrayList<User>() {
			{
				add(new User());
			}
		};
		return users;
	}

}
