package com.tactfactory.testing.adapter;

import java.util.List;

public class Adapter implements Target {
	
	@Override
	public List<User> getUsers(String version) {
		switch (version) {
		case "V1":
			return new Adaptee1().getUsers();
		case "V2":
			return new Adaptee2().getUsers();
		default:
			return null;
		}
	}

}
