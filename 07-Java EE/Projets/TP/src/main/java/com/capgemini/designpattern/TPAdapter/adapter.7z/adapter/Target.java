package com.tactfactory.testing.adapter;

import java.util.List;

public interface Target {

	List<User> getUsers(String version);
}
