package com.tactfactory.testing.adapter;

public class Main {

	public static void main(String[] args) {
		Target t1 = new Adapter();
		t1.getUsers("V1");
	}

}
